# HUMANITY ALERT — Full-stack launch starter

This repository upgrades the original HTML prototype into a Next.js + Supabase public-demo foundation. It is not a fully operational humanitarian service.

## Important launch status

This is a **deployment-ready starter / MVP codebase**, not a certified humanitarian response system. It has not been deployed, penetration-tested, independently audited, or legally reviewed. Do not publicly solicit real child-protection, trafficking, abuse, persecution, or emergency reports until safeguarding, legal, security, and operational partners are in place.

The app intentionally keeps new reports private and under review. It does not expose reporter identity or report text in public pages. The public dashboard only reads aggregate counts. Report tracking reveals status and timestamps only; the report UUID must be treated as a private access token.

## Included

- Responsive public website and report form
- Anonymous report intake and UUID report IDs
- Original language text storage
- Optional English translation provider integration
- Report status lookup with minimal fields (report ID acts as a private access token)
- Supabase email/password authentication
- User dashboard for account-linked reports
- Role-protected moderation page and status updates
- Organization onboarding information page
- Database schema, row-level security policies and audit log table
- Privacy, terms and safeguarding draft pages
- Security response headers

## Stack

- Next.js 15 / React 19 / TypeScript
- Supabase Auth + PostgreSQL
- Server-side service role for report intake (disabled by default)
- Fail-closed Upstash Redis rate limiting and same-origin checks
- Optional LibreTranslate-compatible endpoint
- Optional Resend email provider (notification integration is a next implementation step)

## Setup

1. Create a Supabase project at https://supabase.com.
2. In Supabase SQL Editor, run `supabase/migrations/001_initial.sql`.
3. In Supabase Auth settings, configure your site URL and email redirect URLs. Enable email confirmation.
4. Copy `.env.example` to `.env.local` and fill:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY` (server only; never prefix with `NEXT_PUBLIC_`)
   - `NEXT_PUBLIC_SITE_URL`
   - `REPORT_INTAKE_ENABLED=false` (keep disabled until all safety checks pass)
   - `UPSTASH_REDIS_REST_URL`, `UPSTASH_REDIS_REST_TOKEN`, and a random `RATE_LIMIT_SALT` before considering intake activation
5. Install and run:
   ```bash
   npm install
   npm run dev
   ```
6. Visit http://localhost:3000.

## Translation

Translation is intentionally not called by the public intake route in this release. Do not send potentially sensitive report content to third-party translation services until provider privacy, retention, security and data-processing terms have been reviewed. The legacy translation environment variables are not used.

Set `TRANSLATE_API_URL` to a trusted LibreTranslate-compatible `/translate` endpoint. The current adapter sends `{ q, source: "auto", target: "en", format: "text" }` and optionally a Bearer token. Confirm your provider's exact API contract, privacy terms, retention and data-processing terms before enabling it. If not configured, the original language is stored and translation remains pending; the app does not pretend translation happened.

## Admin bootstrap

New signups receive role `user`. Do not make admin role selectable from the public UI. After creating your trusted administrator account, use Supabase SQL Editor as project owner to assign the role:

```sql
update public.profiles
set role = 'admin'
where id = 'YOUR_AUTH_USER_UUID';
```

Only trusted adult operators should receive admin access. Enable MFA for Supabase admin/operator accounts and keep a separate break-glass owner account.

## Deployment (Vercel)

**Safe default:** report intake is disabled unless `REPORT_INTAKE_ENABLED=true`. Keep it false for a public showcase/demo until an adult legal operator, safeguarding process, abuse controls and incident response are in place. If intake is later enabled, configure Upstash Redis and all required environment variables first. A missing or failing rate limiter blocks submissions.

1. Push this folder to a private GitHub repository.
2. Import it into Vercel.
3. Add all required environment variables in Vercel Project Settings.
4. Deploy and test preview first.
5. Set the production Site URL in Supabase Auth settings and configure allowed redirect URLs.
6. Add a real domain and HTTPS.
7. Test anonymous submission, signup confirmation, user dashboard, moderator access, report tracking and deletion/retention procedures before launch.

## Critical work still required before real public launch

These are intentionally not represented as completed features:

- Independent security review and CAPTCHA/bot-control review. Redis rate limiting is a baseline control, not a substitute for an audit.
- Robust server-side rate limiting and abuse monitoring for anonymous submissions.
- Complete user deletion/export request workflows and documented retention schedule.
- Evidence upload pipeline with private storage, malware scanning, file type/size restrictions and strict access grants. Evidence upload is not enabled in this starter.
- Organization registration workflow, identity verification, category/region matching and partner notification delivery.
- Email notifications (Resend or equivalent), bounce handling, templates and opt-out preferences.
- Automatic translation QA, human review for high-risk languages and safeguarding review.
- Global map/geocoding with generalized locations only.
- Full moderation tooling, escalation policies, duplicate/fraud detection and appeals.
- A staffed safeguarding lead, verified referral partners, monitored contact channels and operational response procedures.
- Public transparency report generation.
- Accessibility audit and professional Bangla translation.
- Legal entity, contact address, reviewed privacy policy/terms, safeguarding policy and incident response plan.

## Safety and privacy design

- Do not publish reports automatically.
- Do not collect precise locations or names of vulnerable people in the public form.
- Child protection and human-rights cases must be routed to trained specialists and must not be public.
- Never promise absolute anonymity: infrastructure providers may process security metadata.
- Do not treat the platform as an emergency dispatch channel.
- Keep the Supabase service role key secret. Rotate it immediately if exposed.

-- HUMANITY ALERT initial schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  role text not null default 'user' check (role in ('user','moderator','admin','organization')),
  created_at timestamptz not null default now()
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid references auth.users(id) on delete set null,
  title text not null check (char_length(title) between 5 and 120),
  country text not null,
  region text not null,
  category text not null,
  original_language text not null,
  original_text text not null,
  english_text text,
  anonymous boolean not null default true,
  status text not null default 'under_review' check (status in ('under_review','verified','in_progress','resolved','rejected')),
  visibility text not null default 'private' check (visibility in ('private','public')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  reviewed_by uuid references auth.users(id) on delete set null
);
create index if not exists reports_status_idx on public.reports(status);
create index if not exists reports_created_idx on public.reports(created_at desc);
create index if not exists reports_country_idx on public.reports(country);

create table if not exists public.organizations (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references auth.users(id) on delete cascade,
  name text not null,
  official_email text not null,
  country text not null,
  regions text[] not null default '{}',
  categories text[] not null default '{}',
  verification_status text not null default 'pending' check (verification_status in ('pending','verified','rejected','suspended')),
  created_at timestamptz not null default now()
);
create table if not exists public.organization_responses (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  report_id uuid not null references public.reports(id) on delete cascade,
  response_status text not null check (response_status in ('notified','accepted','in_progress','completed','unable_to_respond')),
  public_update text,
  created_at timestamptz not null default now()
);
create table if not exists public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references auth.users(id) on delete set null,
  action text not null,
  target_id uuid,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

-- Create profile rows on account signup. New users are never admins.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, display_name, role)
  values(new.id, coalesce(new.raw_user_meta_data->>'display_name',''), 'user')
  on conflict (id) do nothing;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_staff()
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.profiles where id=auth.uid() and role in ('admin','moderator'));
$$;
-- Expose aggregate view without reporter identities or report text.
create or replace view public.public_report_stats as
 select count(*) filter(where visibility='public') as total_reports,
        count(*) filter(where visibility='public' and status='under_review') as under_review,
        count(*) filter(where visibility='public' and status='verified') as verified_reports,
        count(*) filter(where visibility='public' and status='resolved') as resolved_reports
 from public.reports;

alter table public.profiles enable row level security;
alter table public.reports enable row level security;
alter table public.organizations enable row level security;
alter table public.organization_responses enable row level security;
alter table public.audit_logs enable row level security;

create policy "profile self read" on public.profiles for select to authenticated using (id=auth.uid() or public.is_staff());
create policy "profile self update limited" on public.profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid() and role='user');
create policy "report owner or staff read" on public.reports for select to authenticated using (reporter_id=auth.uid() or public.is_staff());
-- Report mutations are performed only by the protected server API using the service role.
-- Do not grant direct authenticated UPDATE access to report records.
create policy "staff read all reports" on public.reports for select to authenticated using (public.is_staff());
create policy "organization owner read" on public.organizations for select to authenticated using (owner_id=auth.uid() or public.is_staff());
create policy "organization owner insert" on public.organizations for insert to authenticated with check (owner_id=auth.uid());
create policy "organization owner update pending" on public.organizations for update to authenticated using (owner_id=auth.uid() and verification_status='pending') with check (owner_id=auth.uid() and verification_status='pending');
create policy "staff manage organizations" on public.organizations for all to authenticated using (public.is_staff()) with check (public.is_staff());
create policy "org response visible to org owner or staff" on public.organization_responses for select to authenticated using (
 exists(select 1 from public.organizations o where o.id=organization_id and o.owner_id=auth.uid()) or public.is_staff()
);
create policy "staff audit read" on public.audit_logs for select to authenticated using (public.is_staff());

-- The API uses the service role for anonymous intake; the service key must never be exposed to browsers.
-- Do not add public SELECT/INSERT policies for reports.
revoke all on public.reports from anon, authenticated;
revoke all on public.audit_logs from anon, authenticated;
revoke all on public.organization_responses from anon, authenticated;
grant select on public.public_report_stats to anon, authenticated;

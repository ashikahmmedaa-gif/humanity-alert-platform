# HUMANITY ALERT — launch status

## What this package is
A Next.js + Supabase prototype that can be presented internationally as an independent humanitarian-technology demonstration after deployment. It is not a registered humanitarian organization, emergency service, aid provider, or verified response network.

## Safe public-demo defaults
- Public report intake is disabled (`REPORT_INTAKE_ENABLED=false`).
- The report form stays disabled unless the feature flag and Upstash Redis settings are present.
- The API independently checks the feature flag, same-origin request, request size, a honeypot field, and a Redis hourly limit (maximum five requests per hashed IP key).
- Redis failure blocks intake rather than allowing unmetered submissions.
- Report text is not sent to an external translation provider.
- Reports are private by default. A report ID is a bearer secret; tracking exposes status and timestamps only.
- Report updates are performed through the protected server API; direct authenticated report updates are not granted by the SQL policy.
- Security headers, privacy/terms drafts and a safeguarding information page are included.

## Still required outside this code package
1. Create and own the Supabase project; apply `supabase/migrations/001_initial.sql`.
2. Create a private GitHub repository and upload this project.
3. Import it into Vercel and set the Supabase environment variables. Keep the service-role key server-only.
4. Set the production site URL in Supabase Auth and configure email redirects.
5. Configure backups, monitoring, account recovery and an adult administrator with MFA.
6. Arrange independent security testing, legal/privacy review, accessibility review and a named safeguarding lead.
7. Establish verified humanitarian referral partners, a monitored contact channel, incident response and data-retention/deletion procedures.
8. Only consider enabling report intake after all operational prerequisites are completed and tested. CAPTCHA/bot-control review is still outstanding.

## Build verification
A dependency install/build could not be completed in the preparation environment because package installation timed out. Run `npm install`, `npm run lint`, and `npm run build` after uploading to a network-enabled development environment. Do not describe the application as production-tested until those checks pass.

## Launch decision
**Suitable target: public demo/showcase only, once deployed and smoke-tested.**

**Not suitable yet: real-world collection of humanitarian, child-protection, trafficking, abuse, persecution, medical or other sensitive reports.**

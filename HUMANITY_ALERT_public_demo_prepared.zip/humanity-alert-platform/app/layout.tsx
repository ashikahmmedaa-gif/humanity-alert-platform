import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "HUMANITY ALERT — Humanitarian Technology Project", description: "An independent prototype exploring safer ways to document humanitarian needs and support responsible coordination. Not an emergency service.", robots: { index: true, follow: true }, openGraph: { title: "HUMANITY ALERT", description: "An independent humanitarian technology project prototype.", type: "website" } };
export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) { return <html lang="en"><body>{children}</body></html>; }

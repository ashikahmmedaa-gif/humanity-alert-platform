import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase-admin";

export const runtime = "nodejs";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id)) {
    return NextResponse.json({ error: "Invalid report ID" }, { status: 400, headers: { "Cache-Control": "no-store" } });
  }
  try {
    const { data, error } = await supabaseAdmin().from("reports")
      .select("id,status,created_at,updated_at")
      .eq("id", id).single();
    if (error || !data) return NextResponse.json({ error: "Report not found" }, { status: 404, headers: { "Cache-Control": "no-store" } });
    return NextResponse.json(data, { headers: { "Cache-Control": "no-store", "Referrer-Policy": "no-referrer" } });
  } catch {
    return NextResponse.json({ error: "Tracking service unavailable" }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }
}

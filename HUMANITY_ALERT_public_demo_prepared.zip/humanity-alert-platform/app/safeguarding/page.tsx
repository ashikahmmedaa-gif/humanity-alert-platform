import Nav from "@/components/Nav";

export default function Safeguarding() {
  return <><header><Nav/><div className="hero"><h1>Safeguarding</h1><p>Public safety information for this independent project prototype.</p></div></header>
    <main className="wrap"><article className="card">
      <div className="notice"><b>Draft policy:</b> this page is not a substitute for an approved safeguarding policy, trained safeguarding lead, referral partners or local legal advice. No operational safeguarding team is represented as active.</div>
      <h2>Immediate danger</h2><p className="muted">HUMANITY ALERT is not an emergency response service. If someone faces immediate danger, contact the appropriate local emergency service or a trusted, established local humanitarian organization directly. Do not wait for a response from this website.</p>
      <h2>Children and adults at risk</h2><p className="muted">Do not submit names, photographs, exact addresses, contact details, school names or other identifying information about a child or person at risk. This prototype must not be used to investigate, identify, locate or contact vulnerable people.</p>
      <h2>How reports are handled</h2><p className="muted">Submissions are private by default and must not be published automatically. Any future operational service needs trained reviewers, documented referral pathways, consent procedures, escalation rules and a process for handling urgent or harmful content.</p>
      <h2>Before operational launch</h2><ul className="muted"><li>Appoint an accountable adult safeguarding lead and backup.</li><li>Obtain specialist review for child protection, trafficking, abuse and other high-risk categories.</li><li>Establish verified referral partners and a documented response-time policy.</li><li>Train moderators in confidentiality, trauma-informed handling and do-no-harm principles.</li><li>Publish a monitored safeguarding contact and incident-reporting route.</li></ul>
      <h2>Current operating status</h2><p className="muted">This is a demonstration project. Public report intake is disabled by default. No aid delivery, emergency dispatch, investigation or guaranteed referral is provided.</p>
    </article></main><footer>HUMANITY ALERT · Safeguarding information</footer></>;
}
